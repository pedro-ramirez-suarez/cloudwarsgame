You are CodeLead Patch Mode.
Generate a read-only patch proposal.
Prefer CodeLead file replacement blocks for small-file snapshot edits with JSON/JSX/HTML/CSS or many quotes; JSON file_replacements is also accepted; use unified diff as fallback.
CO-CHANGE OBLIGATIONS (enforced by patch check):
- If you modify CloudWars.DataAccess/Sql/ICloudWarsData.cs, you MUST also modify: CloudWars.DataAccess/Sql/SqlCloudWarsData.cs.
- If you modify CloudWars.Common/IClientFeedback.cs, you MUST also modify: CloudWars.SpaceBattle/SpaceBattleClientFeedback.cs.
- If you modify CloudWars.Common/IFactory.cs, you MUST also modify: CloudWars.SpaceBattle/SpaceBattleFactory.cs.
- If you modify CloudWars.Common/IGame.cs, you MUST also modify: CloudWars.SpaceBattle/SpaceBattleGame.cs.
- If you modify CloudWars.Common/IPlayerPresence.cs, you MUST also modify: CloudWars.SpaceBattle/SpaceBattlePlayerPresence.cs.
- If you modify CloudWars.Common/Units/IGameUnit.cs, you MUST also modify: CloudWars.SpaceBattle/Units/GameUnit.cs.
Do not claim that files were modified, tests were run, or patches were applied.

Request:
Add one more in-memory characterization fact to the CloudWars.Characterization project, for a behaviour of SpaceBattleGame that the existing facts do not cover; test files only; the root gate must stay green

PREFLIGHT IMPLEMENTATION SPEC

Clear requirements:
- Add one and only one new in-memory characterization fact.
- The fact must belong to the CloudWars.Characterization project.
- The fact must target a behaviour of SpaceBattleGame not already covered by existing facts.
- Only test files may be changed.
- The root gate must remain green.
- The new fact should follow the existing xUnit characterization style.
- The new fact should avoid database-backed behaviour unless the existing in-memory pattern clearly allows it.
- Use default clarification for "Do you have a specific SpaceBattleGame behaviour in mind, or may the coding agent choose any currently uncovered in-memory behaviour?": Choose any uncovered public in-memory behaviour that can be verified without database access.
- Use default clarification for "Should the new fact be added to the existing CloudWars.Characterization/SpaceBattleGameTests.cs file, or is a new test file acceptable?": Add it to the existing SpaceBattleGameTests.cs file.
- Use default clarification for "What exact root gate command must remain green?": Run dotnet build and dotnet test from C:\src\cloudwarsgame.
- Use default clarification for "Are database-backed tests in CloudWars.Characterization.Db expected to run in the validation environment?": Run the full gate if possible; otherwise validate the in-memory project and report the database-dependent limitation.
- Use default clarification for "Is public API-only assertion required, or may the test use reflection if needed?": Use public API only.
- Use default clarification for "Confirm assumption: The new fact will be added to CloudWars.Characterization/SpaceBattleGameTests.cs unless that file is unsuitable.": yes
- Use default clarification for "Confirm assumption: In-memory means no database access, no external I/O, and no use of constructors that load persisted match data.": yes
- Use default clarification for "Confirm assumption: The test should assert only public observable behaviour of SpaceBattleGame.": yes
- Use default clarification for "Confirm assumption: The root gate is dotnet build and dotnet test from the solution root.": yes

Confirmed/default clarifications:
- Do you have a specific SpaceBattleGame behaviour in mind, or may the coding agent choose any currently uncovered in-memory behaviour? Answer: Choose any uncovered public in-memory behaviour that can be verified without database access.. Default used: yes.
- Should the new fact be added to the existing CloudWars.Characterization/SpaceBattleGameTests.cs file, or is a new test file acceptable? Answer: Add it to the existing SpaceBattleGameTests.cs file.. Default used: yes.
- What exact root gate command must remain green? Answer: Run dotnet build and dotnet test from C:\src\cloudwarsgame.. Default used: yes.
- Are database-backed tests in CloudWars.Characterization.Db expected to run in the validation environment? Answer: Run the full gate if possible; otherwise validate the in-memory project and report the database-dependent limitation.. Default used: yes.
- Is public API-only assertion required, or may the test use reflection if needed? Answer: Use public API only.. Default used: yes.
- Confirm assumption: The new fact will be added to CloudWars.Characterization/SpaceBattleGameTests.cs unless that file is unsuitable. Answer: yes. Default used: yes.
- Confirm assumption: In-memory means no database access, no external I/O, and no use of constructors that load persisted match data. Answer: yes. Default used: yes.
- Confirm assumption: The test should assert only public observable behaviour of SpaceBattleGame. Answer: yes. Default used: yes.
- Confirm assumption: The root gate is dotnet build and dotnet test from the solution root. Answer: yes. Default used: yes.

Assumptions:
- The new fact will be added to CloudWars.Characterization/SpaceBattleGameTests.cs unless that file is unsuitable. Status: defaulted. Risk: low.
- In-memory means no database access, no external I/O, and no use of constructors that load persisted match data. Status: defaulted. Risk: low.
- The test should assert only public observable behaviour of SpaceBattleGame. Status: defaulted. Risk: low.
- The root gate is dotnet build and dotnet test from the solution root. Status: defaulted. Risk: medium.
- Existing tests are expected to be green before the change. Status: confirmed. Risk: low.
- Default answer used for "Do you have a specific SpaceBattleGame behaviour in mind, or may the coding agent choose any currently uncovered in-memory behaviour?": Choose any uncovered public in-memory behaviour that can be verified without database access. Status: defaulted. Risk: low.
- Default answer used for "Should the new fact be added to the existing CloudWars.Characterization/SpaceBattleGameTests.cs file, or is a new test file acceptable?": Add it to the existing SpaceBattleGameTests.cs file. Status: defaulted. Risk: low.
- Default answer used for "What exact root gate command must remain green?": Run dotnet build and dotnet test from C:\src\cloudwarsgame. Status: defaulted. Risk: low.
- Default answer used for "Are database-backed tests in CloudWars.Characterization.Db expected to run in the validation environment?": Run the full gate if possible; otherwise validate the in-memory project and report the database-dependent limitation. Status: defaulted. Risk: low.
- Default answer used for "Is public API-only assertion required, or may the test use reflection if needed?": Use public API only. Status: defaulted. Risk: low.
- Default answer used for "Confirm assumption: The new fact will be added to CloudWars.Characterization/SpaceBattleGameTests.cs unless that file is unsuitable.": yes Status: defaulted. Risk: low.
- Default answer used for "Confirm assumption: In-memory means no database access, no external I/O, and no use of constructors that load persisted match data.": yes Status: defaulted. Risk: low.
- Default answer used for "Confirm assumption: The test should assert only public observable behaviour of SpaceBattleGame.": yes Status: defaulted. Risk: low.
- Default answer used for "Confirm assumption: The root gate is dotnet build and dotnet test from the solution root.": yes Status: defaulted. Risk: low.

Relevant files from preflight:
- CloudWars.Characterization/SpaceBattleGameTests.cs
- CloudWars.SpaceBattle/SpaceBattleGame.cs
- CloudWars.Characterization/CloudWars.Characterization.csproj
- CloudWars.Common/IGame.cs
- CloudWars.Common/Other/Enums.cs
- CloudWars.Characterization/GameUnitTests.cs
- CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs
- CloudWars.sln

Constraints:
- Keep changes minimal.
- Reuse existing project patterns.
- Do not introduce new dependencies unless necessary.
- Do not refactor unrelated code.

Validation commands:
- dotnet build
- dotnet test

Preflight patch instructions:
- Use the preflight implementation spec as the source of truth.
- Do not broaden the scope beyond the preflight constraints.
- Do not modify files merely because they were mentioned in project context.
- Only modify files needed to satisfy the clear requirements.
- Return only a unified diff.
- If the preflight says the scope is limited to CSS/HTML styling and icon replacement, do not modify TypeScript/source files unless necessary for icon replacement or existing markup.

Patch generation instructions:
Return CodeLead file replacement blocks for small-file snapshot edits when content contains JSON, JSX/TSX, HTML, CSS, braces, or many quotes; JSON file_replacements is also accepted for easy-to-escape content. CodeLead will generate the unified diff.
Small-file whole-file editing contract:
CodeLead path ignore policy:
- Do not create, modify, snapshot, or ask to repair dependency/build/cache/session artifact paths such as node_modules/**, dist/**, dist-ssr/**, build/**, coverage/**, .next/**, .cache/**, .vite/**, .turbo/**, .parcel-cache/**, .codeleadsessions/**, logs/**, or *.log.
- Treat validation stack frames under those paths as context only; repair project-owned files such as package.json, tsconfig*.json, vite.config.*, postcss.config.*, tailwind.config.*, or source files instead.
- For files listed under Current small file snapshots, return complete replacement content if you need to change them.
- Do not return unified-diff hunks for snapshot files; CodeLead will generate the diff.
- Preserve existing unrelated behavior, imports, exports, comments, and configuration unless the requested change requires modifying them.
- Return the complete file content, not only the changed snippet.
- Use operation "replace" only for files listed in Current small file snapshots.
- Use operation "create" only for new files that do not already exist.
- Use operation "delete" to remove an existing file; leave the content between the markers empty.
- Raw unified diff remains available for large files, unsupported files, or files not listed as small-file snapshots.
- Prefer CodeLead file replacement blocks for JSON, JSX/TSX, HTML, CSS, or content with many quotes/braces.
- In CodeLead file replacement blocks, the start, file, end-file, and end markers must appear exactly as shown.
- Everything between a file marker and <<<END_FILE>>> is raw file content; do not JSON-escape quotes, braces, JSX, or CSS.
Preferred CodeLead file replacement block format:
<<<CODELEAD_FILE_REPLACEMENTS>>>
<<<FILE path="src/App.tsx" operation="replace" reason="Update the app shell.">>>
export function App() {
  return <main />;
}
<<<END_FILE>>>
<<<END_CODELEAD_FILE_REPLACEMENTS>>>
Alternative JSON shape for short content that is easy to escape:
{
  "kind": "file_replacements",
  "files": [
    {
      "operation": "replace",
      "path": "src/App.tsx",
      "content": "export function App() {\\n  return <main />;\\n}\\n",
      "reason": "Update the app shell."
    }
  ]
}
Use raw unified diff only for large files, unsupported files, or files not listed under Current small file snapshots.
Use the exact current file contents above when constructing unified diff context.
For files included under FULL EDIT TARGET FILES, do not invent surrounding context.
For files in FULL EDIT TARGET FILES, use the exact current contents when constructing diff context.
For files in EXPANDED EDIT TARGET CONTEXT, only modify regions you can see in the provided chunks unless the change is trivial and clearly inferable.
Do not invent surrounding context.
Generate hunks that match the provided file contents exactly.
Generate unified diffs whose context lines match the provided current content.
When editing repeated declarations, overloads, or similar blocks, include the target declaration/signature in hunk context when possible.
If a required edit needs unseen parts of a large file, say so instead of inventing context.
Prefer fewer, larger hunks over many tiny hunks when editing nearby lines in the same file.
Do not claim that files were modified, tests were run, or patches were applied.
CodeLead path ignore policy:
- Do not create, modify, snapshot, or ask to repair dependency/build/cache/session artifact paths such as node_modules/**, dist/**, dist-ssr/**, build/**, coverage/**, .next/**, .cache/**, .vite/**, .turbo/**, .parcel-cache/**, .codeleadsessions/**, logs/**, or *.log.
- Treat validation stack frames under those paths as context only; repair project-owned files such as package.json, tsconfig*.json, vite.config.*, postcss.config.*, tailwind.config.*, or source files instead.

Repository summary:
{
  "root": "C:\\src\\cloudwarsgame",
  "projectProfile": {
    "rootPath": "C:\\src\\cloudwarsgame",
    "projectType": "existing",
    "isGreenfield": false,
    "detectedLanguages": [
      {
        "name": "C#",
        "confidence": 0.95,
        "evidence": [
          "Found 68 .cs files",
          "Found CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj",
          "Found CloudWars.Characterization/CloudWars.Characterization.csproj",
          "Found CloudWars.Common/CloudWars.Common.csproj",
          "Found CloudWars.sln"
        ]
      },
      {
        "name": "JavaScript",
        "confidence": 0.72,
        "evidence": [
          "Found 40 .js files"
        ]
      }
    ],
    "detectedTools": [
      {
        "name": ".NET",
        "category": "runtime",
        "confidence": 0.95,
        "evidence": [
          "Found CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj",
          "Found CloudWars.Characterization/CloudWars.Characterization.csproj",
          "Found CloudWars.Common/CloudWars.Common.csproj",
          "Found CloudWars.DataAccess/CloudWars.DataAccess.csproj"
        ]
      },
      {
        "name": ".NET test",
        "category": "test",
        "confidence": 0.85,
        "evidence": [
          "Found common .NET test package in .csproj"
        ]
      }
    ],
    "importantFiles": [
      {
        "path": "CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.Characterization/CloudWars.Characterization.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.Common/CloudWars.Common.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.DataAccess/CloudWars.DataAccess.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.Engine/CloudWars.Engine.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.Entities/CloudWars.Entities.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.Game/CloudWars.Game.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.Glue/CloudWars.Glue.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.SpaceBattle/CloudWars.SpaceBattle.csproj",
        "reason": "C# project file."
      },
      {
        "path": "CloudWars.sln",
        "reason": "C# solution file."
      },
      {
        "path": "docs/codelead/dossier/README.md",
        "reason": "Project documentation."
      }
    ],
    "suggestedValidationCommands": [
      "dotnet build",
      "dotnet test"
    ],
    "summary": "Detected an existing project using C#, JavaScript; tools include .NET, .NET test.",
    "notes": [
      "This appears to be an existing project.",
      "Follow existing project structure, languages, tools, dependencies, and patterns.",
      "Do not introduce new dependencies unless clearly needed.",
      "Use suggested validation commands when appropriate: dotnet build, dotnet test."
    ]
  },
  "scannedFileCount": 184,
  "fileTreeSummary": [
    "CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj",
    "CloudWars.Characterization.Db/Net8Bootstrap.cs",
    "CloudWars.Characterization.Db/SpaceBattleClientFeedbackDbTests.cs",
    "CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs",
    "CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs",
    "CloudWars.Characterization.Db/SpaceBattleGameMatchFinishedDbTests.cs",
    "CloudWars.Characterization.Db/SpaceBattlePlayerPresenceDbTests.cs",
    "CloudWars.Characterization/CloudWars.Characterization.csproj",
    "CloudWars.Characterization/GameUnitTests.cs",
    "CloudWars.Characterization/SpaceBattleGameTests.cs",
    "CloudWars.Common/CloudWars.Common.csproj",
    "CloudWars.Common/IClientFeedback.cs",
    "CloudWars.Common/IFactory.cs",
    "CloudWars.Common/IGame.cs",
    "CloudWars.Common/IPlayerPresence.cs",
    "CloudWars.Common/Other/...",
    "CloudWars.Common/Properties/...",
    "CloudWars.Common/Units/...",
    "CloudWars.DataAccess/CloudWars.DataAccess.csproj",
    "CloudWars.DataAccess/Properties/...",
    "CloudWars.DataAccess/Queue/...",
    "CloudWars.DataAccess/Sql/...",
    "CloudWars.Engine/CloudWars.Engine.csproj",
    "CloudWars.Engine/Properties/...",
    "CloudWars.Engine/WorkerRole.cs",
    "CloudWars.Entities/CloudWars.Entities.csproj",
    "CloudWars.Entities/Game/...",
    "CloudWars.Entities/Player/...",
    "CloudWars.Entities/Properties/...",
    "CloudWars.Game/App_Start/...",
    "CloudWars.Game/CloudWars.Game.csproj",
    "CloudWars.Game/Code/...",
    "CloudWars.Game/Content/...",
    "CloudWars.Game/Controllers/...",
    "CloudWars.Game/Filters/...",
    "CloudWars.Game/Global.asax.cs",
    "CloudWars.Game/Migrations/...",
    "CloudWars.Game/Models/...",
    "CloudWars.Game/Properties/...",
    "CloudWars.Game/Readme.md",
    "CloudWars.Game/Scripts/...",
    "CloudWars.Game/ServerClientEntities/...",
    "CloudWars.Game/Views/...",
    "CloudWars.Glue/Class1.cs",
    "CloudWars.Glue/CloudWars.Glue.csproj",
    "CloudWars.Glue/Properties/...",
    "CloudWars.SpaceBattle/CloudWars.SpaceBattle.csproj",
    "CloudWars.SpaceBattle/Properties/...",
    "CloudWars.SpaceBattle/SpaceBattleClientFeedback.cs",
    "CloudWars.SpaceBattle/SpaceBattleFactory.cs",
    "CloudWars.SpaceBattle/SpaceBattleGame.cs",
    "CloudWars.SpaceBattle/SpaceBattlePlayerPresence.cs",
    "CloudWars.SpaceBattle/Units/...",
    "CloudWars.sln",
    "Directory.Build.props",
    "Readme.md",
    "docs/codelead/...",
    "license.md",
    "pilot-after/README.txt",
    "pilot-after/build-summary.json",
    "pilot-after/environment.json",
    "pilot-after/idiom-counts-by-project.json",
    "pilot-after/idiom-counts.json",
    "pilot-after/projects.json",
    "pilot-before/README.txt",
    "pilot-before/build-summary.json",
    "pilot-before/environment.json",
    "pilot-before/idiom-counts.json",
    "pilot-before/projects.json"
  ],
  "contextPack": {
    "summary": "Selected 12 files: 9 source, 3 test, 0 project/config anchors, 10 relationship-linked.",
    "notes": [
      "ContextPack used ProjectLibrary roles, symbols, tokens, modules, and relationships."
    ],
    "selectedFiles": [
      {
        "path": "CloudWars.Game/Models/AccountModels.cs",
        "role": "source",
        "language": "C#",
        "score": 1000,
        "reasonTypes": [
          "lexical-match",
          "symbol-match",
          "type-declaration"
        ],
        "reason": "lexical match; symbol/token match for cloud, war, game, public, default"
      },
      {
        "path": "CloudWars.Entities/Game/Match.cs",
        "role": "source",
        "language": "C#",
        "score": 1000,
        "reasonTypes": [
          "lexical-match",
          "symbol-match",
          "type-declaration"
        ],
        "reason": "lexical match; symbol/token match for cloud, war, game, public, can"
      },
      {
        "path": "CloudWars.Common/Other/Enums.cs",
        "role": "source",
        "language": "C#",
        "score": 1000,
        "reasonTypes": [
          "lexical-match",
          "related-source",
          "relationship",
          "symbol-match",
          "type-declaration"
        ],
        "reason": "lexical match; symbol/token match for cloud, war, public, not, game; related source file for selected context"
      },
      {
        "path": "CloudWars.Common/IGame.cs",
        "role": "source",
        "language": "C#",
        "score": 855,
        "reasonTypes": [
          "lexical-match",
          "related-source",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for game, cloud, war, unit, public; related source file for selected context"
      },
      {
        "path": "CloudWars.Common/IClientFeedback.cs",
        "role": "source",
        "language": "C#",
        "score": 855,
        "reasonTypes": [
          "lexical-match",
          "module-anchor",
          "related-source",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for cloud, war, public, unit; related source file for selected context; module match"
      },
      {
        "path": "CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs",
        "role": "test",
        "language": "C#",
        "score": 855,
        "reasonTypes": [
          "lexical-match",
          "related-test",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for space, battle, game, test, cloud; related test file for selected context"
      },
      {
        "path": "CloudWars.Characterization.Db/SpaceBattleClientFeedbackDbTests.cs",
        "role": "test",
        "language": "C#",
        "score": 855,
        "reasonTypes": [
          "lexical-match",
          "related-test",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for space, battle, test, cloud, war; related test file for selected context"
      },
      {
        "path": "CloudWars.SpaceBattle/SpaceBattleClientFeedback.cs",
        "role": "source",
        "language": "C#",
        "score": 732,
        "reasonTypes": [
          "lexical-match",
          "related-source",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for space, battle, cloud, war, game; related source file for selected context"
      },
      {
        "path": "CloudWars.Common/Units/IGameUnit.cs",
        "role": "source",
        "language": "C#",
        "score": 732,
        "reasonTypes": [
          "lexical-match",
          "related-source",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for game, unit, cloud, war, public; related source file for selected context"
      },
      {
        "path": "CloudWars.SpaceBattle/SpaceBattleGame.cs",
        "role": "source",
        "language": "C#",
        "score": 627,
        "reasonTypes": [
          "lexical-match",
          "related-source",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for space, battle, game, cloud, war; related source file for selected context"
      },
      {
        "path": "CloudWars.Game/Controllers/GameController.cs",
        "role": "source",
        "language": "C#",
        "score": 627,
        "reasonTypes": [
          "lexical-match",
          "related-source",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for game, cloud, war, space, battle; related source file for selected context"
      },
      {
        "path": "CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs",
        "role": "test",
        "language": "C#",
        "score": 627,
        "reasonTypes": [
          "lexical-match",
          "related-test",
          "relationship",
          "symbol-match"
        ],
        "reason": "lexical match; symbol/token match for space, battle, game, test, cloud; related test file for selected context"
      }
    ]
  }
}

PROJECT STACK AND TEMPLATE CONVENTIONS

Detected project stack:
- Languages: C#, JavaScript
- Tools: .NET, .NET test

Detected template/binding conventions:
No dominant template binding convention detected.

Instruction:
Preserve the project's existing template/binding conventions.
Do not introduce syntax from a different web framework unless the request explicitly asks for a framework migration.

PATCH PLAN

Expected affected files:
1. CloudWars.Characterization/SpaceBattleGameTests.cs - required - likely_edit_target; selected because Existing in-memory SpaceBattleGame characterization facts; likely location for the new fact.
2. CloudWars.SpaceBattle/SpaceBattleGame.cs - supporting - likely_edit_target; selected because lexical match; symbol/token match for space, battle, game, cloud, war; related source file for selected context; symbol retrieval: symbols SpaceBattleGame/CreateMatch/PauseMatch match space,battle,game,match,unit
3. CloudWars.Characterization/CloudWars.Characterization.csproj - supporting - likely_edit_target; selected because Confirms test project target, framework, and test dependencies.
4. CloudWars.Common/IGame.cs - supporting - likely_edit_target; selected because lexical match; symbol/token match for game, cloud, war, unit, public; related source file for selected context
5. CloudWars.Common/Other/Enums.cs - supporting - likely_edit_target; selected because lexical match; symbol/token match for cloud, war, public, not, game; related source file for selected context
6. CloudWars.Characterization/GameUnitTests.cs - supporting - supporting_context; selected because Shows existing in-memory test style and assertion patterns.
7. CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs - supporting - supporting_context; selected because Useful contrast to avoid database-backed characterization patterns.
8. CloudWars.sln - supporting - supporting_context; selected because Root solution used for build/test gate.
9. CloudWars.DataAccess/Sql/CloudWarsDB.cs - supporting - supporting_context; selected because symbol retrieval: symbols CloudWarsDB match cloud,wars; file name matches cloud,wars
10. CloudWars.DataAccess/Sql/CloudWarsData.cs - supporting - supporting_context; selected because symbol retrieval: symbols CloudWarsData/CreateMatch/DeleteMatch match cloud,wars,data,match,unit,add; file name matches cloud,wars,data
11. CloudWars.Entities/Game/Match.cs - supporting - supporting_context; selected because lexical match; symbol/token match for cloud, war, game, public, can; symbol retrieval: symbols Match match match
12. CloudWars.Entities/Player/Player.cs - supporting - supporting_context; selected because symbol retrieval: symbols  match ; references edge from seed SpaceBattleClientFeedbackDbTests.cs: uses type Player
13. CloudWars.Entities/Game/MatchUnit.cs - supporting - supporting_context; selected because symbol retrieval: symbols MatchUnit match match,unit; file name matches match,unit

Instructions:
- Generate a unified diff for this plan.
- Do not omit expected files unless the requested change truly does not require them.
- Do not add files outside this plan unless necessary.
- Do not invent files.
- If a file contains repeated declarations, overloads, or similar blocks, include the target declaration/signature in the hunk context when possible.

Current small file snapshots

### CloudWars.Characterization/SpaceBattleGameTests.cs
Hash: 3930aacde8250bbf9dfac7a8633462629a7a478e54ed0bee0d3d706802029bb7
Size: 1802 bytes
```text
using System;
using CloudWars.Common;
using CloudWars.Common.Other;
using CloudWars.SpaceBattle;
using Xunit;

namespace CloudWars.Characterization
{
    public class SpaceBattleGameTests
    {
        [Fact]
        public void ParameterlessConstructor_Units_IsNull()
        {
            var game = new SpaceBattleGame();

            Assert.Null(game.Units);
        }

        [Fact]
        public void TwoParamConstructor_LoadFalse_SetsMatchId_LeavesTurnAndReadyFlagsAtDefaults()
        {
            var matchId = Guid.NewGuid();
            var game = new SpaceBattleGame(matchId, false);

            Assert.Equal(matchId, game.MatchId);
            Assert.Equal(Guid.Empty, game.Turn);
            Assert.False(game.Player1Ready);
            Assert.False(game.Player2Ready);
        }

        [Fact]
        public void PlayerAttack_PlayerIdNotCurrentTurn_ReturnsNotYourTurn_ShotMissed_WithoutTouchingUnits()
        {
            var game = new SpaceBattleGame();
            var player1 = Guid.NewGuid();
            var player2 = Guid.NewGuid();
            var attacker = Guid.NewGuid(); // deliberately not the current turn

            game.Player1 = player1;
            game.Player2 = player2;
            game.Turn = player1;

            var unitsBefore = game.Units; // null

            var result = game.PlayerAttack(new Position { Row = 0, Column = 0 }, attacker);

            Assert.Equal(Command.NotYourTurn, result.Command);
            Assert.Equal(GameAction.ShotMissed, result.Action);
            Assert.Equal(game.MatchId, result.MatchId);
            Assert.Equal(player1, result.Player1);
            Assert.Equal(player2, result.Player2);
            Assert.Same(unitsBefore, game.Units);
        }
    }
}

```

### CloudWars.SpaceBattle/SpaceBattleGame.cs
Hash: 991dbee866d248ee5ce4462a3bcdaa456870b513587f72cb32eb8184699e33d1
Size: 8698 bytes
```text
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common;
using CloudWars.Common.Other;
using CloudWars.Common.Units;
using CloudWars.SpaceBattle.Units;
using CloudWars.DataAccess.Sql;
using CloudWars.Entities.Game;

namespace CloudWars.SpaceBattle
{
	public class SpaceBattleGame: IGame
	{
        public List<IGameUnit> Units { get; private set; }
        public Guid MatchId { get; set; }
        public Guid Player1 { get; set; }
        public Guid Player2 { get; set; }
        public Guid Turn { get; set; }
        public bool Player1Ready { get; set; }
        public bool Player2Ready { get; set; }
        bool Initialized { get; set; }
        bool MatchEnded { get; set; }
        bool PlayingNow { get; set; }
        Guid Winner { get; set; }
        private readonly ICloudWarsData _data;
        

        public SpaceBattleGame(ICloudWarsData data)
        {
            _data = data;
        }

        public SpaceBattleGame(Guid matchId, bool loadMatchData) : this(new SqlCloudWarsData())
        {
            //load the match
            if (loadMatchData)
            {
                var m = _data.GetMatch(matchId);
                this.MatchId = m.Id;
                this.Player1 = m.Player1;
                this.Player2 = m.Player2;
                this.Player1Ready = m.Player1Ready;
                this.Player2Ready = m.Player2Ready;
                this.Turn = m.Turn;
                this.Initialized = m.Initialized;
                this.MatchEnded = m.MatchEnded;
                this.Winner = m.Winner;
                this.PlayingNow = m.PlayingNow;
                //Get the units
                var dbUnits = _data.GetUnits(matchId);
                Units = new List<IGameUnit>();
                foreach (var u in dbUnits)
                {
                    Units.Add(new GameUnit(u));
                }
            }
            else
            {
                this.MatchId = matchId;
            }
        }

        

        public SpaceBattleGame() : this(new SqlCloudWarsData())
        { 
        }

        /// <summary>
        /// Create the match and 
        /// </summary>
        public void CreateMatch(Guid player1, Guid player2)
        {
            Player1 = player1;
            Player2 = player2;
            //Create the match and set the matchid
            MatchId = _data.CreateMatch(player1, player2);
            Turn = player1;
        }

        /// <summary>
        /// This is used when the Match is created
        /// </summary>
        /// <param name="initialState"></param>
        public void Initialize(object initialState)
        {
            Initialized = true;
            //save the match
            UpdateMatch();

        }

        public void PlayerReady(Guid playerId)
        {
            if (playerId == Player1)
                Player1Ready = true;
            else
                Player2Ready = true;
            if (Player1Ready && Player2Ready)
                Initialized = true;
            //save the match
            UpdateMatch();
        }

        public void PlayerMoveTo(Position coordinates,Guid unitId)
        {
            //does not allow moves after initialization
            if (Initialized)
                return;
            var unit = Units.FirstOrDefault(u => u.UnitId == unitId);
            if (unit != null)
            {
                UpdateUnit(columns: new { Row = coordinates.Row, Col = coordinates.Column }, where: new { MatchId = unit.MatchId, And_UnitId = unit.UnitId, And_PlayerId = unit.PlayerId } );
            }
        }

        public Message PlayerAttack(Position coordinates, Guid playerId)
        {
            //check if its player turn and that the game is active
            if (Turn != playerId || !this.PlayingNow)
                return new Message { Action = GameAction.ShotMissed, Player1 = Player1, Player2 = Player2, Command = Command.NotYourTurn, MatchId = MatchId };
            
            //determine if its a hit 
            var unit = Units.FirstOrDefault(u => u.Row == coordinates.Row && u.Column == coordinates.Column && u.PlayerId != playerId);
            bool wasHit;
            if (unit != null && unit.Health > 0)
            {
                //update the unit status, and queue a message
                unit.TakeDamage(1);
                UpdateUnit(columns: new { Health = unit.Health }, where: new { MatchId = unit.MatchId, And_UnitId = unit.UnitId, And_PlayerId = unit.PlayerId });
                wasHit = true;
            }
            else
            {
                wasHit = false;
            }
            //queue proper message            
            if (wasHit)
            {
                //check if player won the match
                if (Units.Count(u => u.Health > 0 && u.PlayerId != playerId) == 0)
                {
                    //inform players the match result                    
                    return MatchFinished(winner: playerId, losser: unit.PlayerId);
                }
                else
                {
                    //inform the hit
                    var msg = new Message { Action = GameAction.ShotMade,  Player1 = Player1, Player2 = Player2, Command = Command.GameAction, HealthAfterAttack = unit.Health, MatchId = MatchId, UnitId = unit.UnitId, Coordinates = coordinates };
                    return msg;
                }
            }
            else
            { 
                //inform the missing
                var msg = new Message { Action = GameAction.ShotMissed, Player1 = Player1, Player2 = Player2, Command = Command.GameAction,  MatchId = MatchId, Coordinates = coordinates };
                
                //change the turn
                Turn = Turn == Player1 ? Player2 : Player1;
                UpdateMatch();
                return msg;
            }
            
            
        }

        public void PauseMatch()
        {
            this.PlayingNow = false;
            this.Player1Ready = false;
            this.Player2Ready = false;
            UpdateMatch();
        }


        public void RestartMatch()
        {
            UpdateMatch(new { PlayingNow = true}, new { Id = this.MatchId });
        }



        public Message MatchFinished(Guid winner, Guid losser)
        {
            //update player stats
            _data.PlayerWin(winner);
            _data.PlayerLose(losser);
            //delete the match
            _data.DeleteMatch(this.MatchId);
            //return the message
            return new Message { Winner = winner, Losser = losser, Command = Command.EndGame,  MatchId = this.MatchId };
        }

        private void UpdateUnit(object columns, object where)
        {
            _data.UpdateMatchUnit(values: columns, where: where);
        }

        private void UpdateMatch()
        {
            var cols = new { Turn = this.Turn, Player1Ready = this.Player1Ready, Player2Ready = this.Player2Ready, Initialized = this.Initialized, MatchEnded = this.MatchEnded, Winner = this.Winner, PlayingNow = this.PlayingNow };
            var where = new { Id = this.MatchId };
            _data.UpdateMatch(values: cols, where: where);
        }

        private void UpdateMatch(object columns, object where)
        {
            _data.UpdateMatch(values: columns, where: where);
        }

        private void UpdatePlayer(object columns, object where)
        {
            _data.UpdatePlayer(values: columns, where: where);
        }
        

        public void ChallengePlayer(Guid fromId, Guid toId)
        {
            _data.ChallengePlayer(fromId, toId);
        }

        public Tuple<Guid, Guid, Guid> AcceptChallenge(Guid challengeId)
        {
            //Get the challenge 
            var c = _data.GetChallenge (challengeId );
            //accept the challenge and create the match
            _data.AcceptChallenge(challengeId);
            this.CreateMatch(c.Player1, c.Player2);
            return new Tuple<Guid, Guid, Guid>(this.MatchId, c.Player1, c.Player2);
        }


        public Tuple<string, string> RejectChallenge(Guid challengeId)
        {
            var c = _data.GetChallenge(challengeId);
            var p1 = _data.GetPlayer(c.Player1);
            var p2 = _data.GetPlayer(c.Player2);
            _data.RejectChallenge(challengeId);
            return new Tuple<string, string>(p1.ClientId, p2.DisplayName);

        }
    }
}

```

### CloudWars.Characterization/CloudWars.Characterization.csproj
Hash: 19114475cb71aa176026c0a2374b5b7784faaefae611d2d02ce1f1e8387bebf4
Size: 785 bytes
```text
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <ImplicitUsings>disable</ImplicitUsings>
    <Nullable>disable</Nullable>
    <IsPackable>false</IsPackable>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.9.0" />
    <PackageReference Include="xunit" Version="2.7.0" />
    <PackageReference Include="xunit.runner.visualstudio" Version="2.5.7" />
  </ItemGroup>

  <ItemGroup>
    <ProjectReference Include="..\CloudWars.SpaceBattle\CloudWars.SpaceBattle.csproj" />
    <ProjectReference Include="..\CloudWars.Entities\CloudWars.Entities.csproj" />
    <ProjectReference Include="..\CloudWars.Common\CloudWars.Common.csproj" />
  </ItemGroup>

</Project>

```

### CloudWars.Common/IGame.cs
Hash: 0008fee9e961e48439fffe6a131a6bf8b0a07a072a47af90c1540a0449be1803
Size: 1234 bytes
```text
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common.Units;
using CloudWars.Common.Other;

namespace CloudWars.Common
{
    public interface IGame
    {
        void ChallengePlayer(Guid fromId, Guid toId);
        
        /// <summary>
        /// Accept the challenge 
        /// </summary>
        /// <returns>MatchId, player 1 id, player 2 id</returns>
        Tuple<Guid,Guid,Guid> AcceptChallenge(Guid challengeId);
        Tuple<string, string> RejectChallenge(Guid challengeId);
        void CreateMatch(Guid player1, Guid player2);
        void Initialize(object initialState);
        void PlayerMoveTo(Position coordinates, Guid unitId);
        Message PlayerAttack(Position coordinates, Guid playerId);
        void PlayerReady(Guid playerId);
        Message MatchFinished(Guid winner, Guid losser);
        Guid MatchId { get; set; }
        Guid Player1 { get; set; }
        Guid Player2 { get; set; }
        Guid Turn { get; set; }
        bool Player1Ready { get; set; }
        bool Player2Ready { get; set; }
        void PauseMatch();
        void RestartMatch();
        List<IGameUnit> Units { get; }
    }

}

```

### CloudWars.Common/Other/Enums.cs
Hash: 22fbec781b89bb53c83d55fb3beda7e8f119abebbb8c9113cda2649c9f040287
Size: 512 bytes
```text
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CloudWars.Common.Other
{
    public enum Command 
    { 
        NotYourTurn,
        ChallengePlayer,
        ChallengeAccepted,
        StartGame,
        EndGame,
        PlayerOnline,
        PlayerOffLine,
        GameAction
    }


    public enum GameAction
    { 
        PlayerReady,
        UnitMoved,
        Attack,
        ShotMade,
        ShotMissed
    }
        
}

```

### CloudWars.Entities/Game/MatchUnit.cs
Hash: 708137982c7f2085f6366ad68ede583f48a7a8ff9054e79de92bf1ff16193a5b
Size: 639 bytes
```text
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;

namespace CloudWars.Entities.Game
{
    public class MatchUnit
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public Guid PlayerId { get; set; }
        public Guid MatchId { get; set; }
        public Guid UnitId { get; set; }
        public string Name { get; set; }
        public int MaxHealth { get; set; }
        public int Health { get; set; }
        public int Row { get; set; }
        public int Col { get; set; }
    }
}

```

### CloudWars.Entities/Game/Match.cs
Hash: ac4e903e43a9729fe7b496bab6e5a906ab8e670437c90ede6970ca62cc730c98
Size: 706 bytes
```text
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;

namespace CloudWars.Entities.Game
{
    public class Match
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public Guid Player1 { get; set; }
        public Guid Player2 { get; set; }
        public Guid Turn { get; set; }
        public bool Player1Ready { get; set; }
        public bool Player2Ready { get; set; }
        public bool Initialized { get; set; }
        public bool MatchEnded { get; set; }
        public Guid Winner { get; set; }
        public bool PlayingNow { get; set; }
    }
}

```

### CloudWars.Entities/Player/Player.cs
Hash: 91456534fdd3f86135a64c2f1021be876072351b46993c0c6ba680db2b25b4d8
Size: 794 bytes
```text
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;
using Microsoft.SqlServer.Types;

namespace CloudWars.Entities.Player
{
    public class Player
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public string DisplayName { get; set; }
        public string Avatar { get; set; }
        public int Wins { get; set; }
        public int Losses { get; set; }
        public string Status { get; set; }
        public bool IsOnline { get; set; }
        public DateTime LastActivity { get; set; }
        public SqlGeography Location { get;set; }
        public string ClientId { get; set; }
        public string LiveId { get; set; }
    }
}

```

FULL EDIT TARGET FILES

File: CloudWars.DataAccess/Sql/CloudWarsDB.cs
Reason: likely edit target; small file; symbol retrieval: symbols CloudWarsDB match cloud,wars; file name matches cloud,wars
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;
using CloudWars.Entities.Game;
using CloudWars.Entities.Player;
using Needletail.DataAccess;

namespace CloudWars.DataAccess.Sql
{
    public class CloudWarsDB
    {
        /// <summary>
        /// The connection string for the game
        /// </summary>
        public const string ConnectionString = "DefaultConnection";

        static DBTableDataSourceBase<Match, Guid> _Matches = new DBTableDataSourceBase<Match, Guid> (ConnectionString, "Match");
        public static DBTableDataSourceBase<Match, Guid> Matches
        {
            get 
            {
                return _Matches;
            }
        }


        static DBTableDataSourceBase<MatchUnit, Guid> _MatchUnits = new DBTableDataSourceBase<MatchUnit, Guid>(ConnectionString, "MatchUnit");
        public static DBTableDataSourceBase<MatchUnit, Guid> MatchUnits
        {
            get
            {
                return _MatchUnits;
            }
        }


        static DBTableDataSourceBase<PlayerUnit, Guid> _PlayerUnits = new DBTableDataSourceBase<PlayerUnit, Guid>(ConnectionString, "PlayerUnit");
        static DBTableDataSourceBase<PlayerUnit, Guid> PlayerUnits
        {
            get
            {
                return _PlayerUnits;
            }
        }


        static DBTableDataSourceBase<Player, Guid> _Players = new DBTableDataSourceBase<Player, Guid>(ConnectionString, "Player");
        public static DBTableDataSourceBase<Player, Guid> Players
        {
            get
            {
                return _Players;
            }
        }

        static IEnumerable<PlayerUnit> _VanillaUnits;
        public static IEnumerable<PlayerUnit> VanillaUnits 
        {
            get 
            {
                if (_VanillaUnits == null)
                {
                    _VanillaUnits = PlayerUnits.GetAll();
                }
                return _VanillaUnits;
            }
        }

        static DBTableDataSourceBase<PlayerNotification, Guid> _PlayerNotifications = new DBTableDataSourceBase<PlayerNotification, Guid>(ConnectionString, "PlayerNotification");
        public static DBTableDataSourceBase<PlayerNotification, Guid> PlayerNotifications
        {
            get
            {
                return _PlayerNotifications;
            }
        }


        static DBTableDataSourceBase<Challenge, Guid> _Challenges = new DBTableDataSourceBase<Challenge, Guid>(ConnectionString, "Challenge");
        public static DBTableDataSourceBase<Challenge, Guid> Challenges
        {
            get
            {
                return _Challenges;
            }
        }
    }
}
```

File: CloudWars.SpaceBattle/SpaceBattleGame.cs
Reason: likely edit target; small file; reasons lexical-match, related-source, relationship, symbol-match; lexical match; symbol/token match for space, battle, game, cloud, war; related source file for selected context; symbol retrieval: symbols SpaceBattleGame/CreateMatch/PauseMatch match space,battle,game,match,unit
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common;
using CloudWars.Common.Other;
using CloudWars.Common.Units;
using CloudWars.SpaceBattle.Units;
using CloudWars.DataAccess.Sql;
using CloudWars.Entities.Game;

namespace CloudWars.SpaceBattle
{
	public class SpaceBattleGame: IGame
	{
        public List<IGameUnit> Units { get; private set; }
        public Guid MatchId { get; set; }
        public Guid Player1 { get; set; }
        public Guid Player2 { get; set; }
        public Guid Turn { get; set; }
        public bool Player1Ready { get; set; }
        public bool Player2Ready { get; set; }
        bool Initialized { get; set; }
        bool MatchEnded { get; set; }
        bool PlayingNow { get; set; }
        Guid Winner { get; set; }
        private readonly ICloudWarsData _data;
        

        public SpaceBattleGame(ICloudWarsData data)
        {
            _data = data;
        }

        public SpaceBattleGame(Guid matchId, bool loadMatchData) : this(new SqlCloudWarsData())
        {
            //load the match
            if (loadMatchData)
            {
                var m = _data.GetMatch(matchId);
                this.MatchId = m.Id;
                this.Player1 = m.Player1;
                this.Player2 = m.Player2;
                this.Player1Ready = m.Player1Ready;
                this.Player2Ready = m.Player2Ready;
                this.Turn = m.Turn;
                this.Initialized = m.Initialized;
                this.MatchEnded = m.MatchEnded;
                this.Winner = m.Winner;
                this.PlayingNow = m.PlayingNow;
                //Get the units
                var dbUnits = _data.GetUnits(matchId);
                Units = new List<IGameUnit>();
                foreach (var u in dbUnits)
                {
                    Units.Add(new GameUnit(u));
                }
            }
            else
            {
                this.MatchId = matchId;
            }
        }

        

        public SpaceBattleGame() : this(new SqlCloudWarsData())
        { 
        }

        /// <summary>
        /// Create the match and 
        /// </summary>
        public void CreateMatch(Guid player1, Guid player2)
        {
            Player1 = player1;
            Player2 = player2;
            //Create the match and set the matchid
            MatchId = _data.CreateMatch(player1, player2);
            Turn = player1;
        }

        /// <summary>
        /// This is used when the Match is created
        /// </summary>
        /// <param name="initialState"></param>
        public void Initialize(object initialState)
        {
            Initialized = true;
            //save the match
            UpdateMatch();

        }

        public void PlayerReady(Guid playerId)
        {
            if (playerId == Player1)
                Player1Ready = true;
            else
                Player2Ready = true;
            if (Player1Ready && Player2Ready)
                Initialized = true;
            //save the match
            UpdateMatch();
        }

        public void PlayerMoveTo(Position coordinates,Guid unitId)
        {
            //does not allow moves after initialization
            if (Initialized)
                return;
            var unit = Units.FirstOrDefault(u => u.UnitId == unitId);
            if (unit != null)
            {
                UpdateUnit(columns: new { Row = coordinates.Row, Col = coordinates.Column }, where: new { MatchId = unit.MatchId, And_UnitId = unit.UnitId, And_PlayerId = unit.PlayerId } );
            }
        }

        public Message PlayerAttack(Position coordinates, Guid playerId)
        {
            //check if its player turn and that the game is active
            if (Turn != playerId || !this.PlayingNow)
                return new Message { Action = GameAction.ShotMissed, Player1 = Player1, Player2 = Player2, Command = Command.NotYourTurn, MatchId = MatchId };
            
            //determine if its a hit 
            var unit = Units.FirstOrDefault(u => u.Row == coordinates.Row && u.Column == coordinates.Column && u.PlayerId != playerId);
            bool wasHit;
            if (unit != null && unit.Health > 0)
            {
                //update the unit status, and queue a message
                unit.TakeDamage(1);
                UpdateUnit(columns: new { Health = unit.Health }, where: new { MatchId = unit.MatchId, And_UnitId = unit.UnitId, And_PlayerId = unit.PlayerId });
                wasHit = true;
            }
            else
            {
                wasHit = false;
            }
            //queue proper message            
            if (wasHit)
            {
                //check if player won the match
                if (Units.Count(u => u.Health > 0 && u.PlayerId != playerId) == 0)
                {
                    //inform players the match result                    
                    return MatchFinished(winner: playerId, losser: unit.PlayerId);
                }
                else
                {
                    //inform the hit
                    var msg = new Message { Action = GameAction.ShotMade,  Player1 = Player1, Player2 = Player2, Command = Command.GameAction, HealthAfterAttack = unit.Health, MatchId = MatchId, UnitId = unit.UnitId, Coordinates = coordinates };
                    return msg;
                }
            }
            else
            { 
                //inform the missing
                var msg = new Message { Action = GameAction.ShotMissed, Player1 = Player1, Player2 = Player2, Command = Command.GameAction,  MatchId = MatchId, Coordinates = coordinates };
                
                //change the turn
                Turn = Turn == Player1 ? Player2 : Player1;
                UpdateMatch();
                return msg;
            }
            
            
        }

        public void PauseMatch()
        {
            this.PlayingNow = false;
            this.Player1Ready = false;
            this.Player2Ready = false;
            UpdateMatch();
        }


        public void RestartMatch()
        {
            UpdateMatch(new { PlayingNow = true}, new { Id = this.MatchId });
        }



        public Message MatchFinished(Guid winner, Guid losser)
        {
            //update player stats
            _data.PlayerWin(winner);
            _data.PlayerLose(losser);
            //delete the match
            _data.DeleteMatch(this.MatchId);
            //return the message
            return new Message { Winner = winner, Losser = losser, Command = Command.EndGame,  MatchId = this.MatchId };
        }

        private void UpdateUnit(object columns, object where)
        {
            _data.UpdateMatchUnit(values: columns, where: where);
        }

        private void UpdateMatch()
        {
            var cols = new { Turn = this.Turn, Player1Ready = this.Player1Ready, Player2Ready = this.Player2Ready, Initialized = this.Initialized, MatchEnded = this.MatchEnded, Winner = this.Winner, PlayingNow = this.PlayingNow };
            var where = new { Id = this.MatchId };
            _data.UpdateMatch(values: cols, where: where);
        }

        private void UpdateMatch(object columns, object where)
        {
            _data.UpdateMatch(values: columns, where: where);
        }

        private void UpdatePlayer(object columns, object where)
        {
            _data.UpdatePlayer(values: columns, where: where);
        }
        

        public void ChallengePlayer(Guid fromId, Guid toId)
        {
            _data.ChallengePlayer(fromId, toId);
        }

        public Tuple<Guid, Guid, Guid> AcceptChallenge(Guid challengeId)
        {
            //Get the challenge 
            var c = _data.GetChallenge (challengeId );
            //accept the challenge and create the match
            _data.AcceptChallenge(challengeId);
            this.CreateMatch(c.Player1, c.Player2);
            return new Tuple<Guid, Guid, Guid>(this.MatchId, c.Player1, c.Player2);
        }


        public Tuple<string, string> RejectChallenge(Guid challengeId)
        {
            var c = _data.GetChallenge(challengeId);
            var p1 = _data.GetPlayer(c.Player1);
            var p2 = _data.GetPlayer(c.Player2);
            _data.RejectChallenge(challengeId);
            return new Tuple<string, string>(p1.ClientId, p2.DisplayName);

        }
    }
}
```

File: CloudWars.DataAccess/Sql/CloudWarsData.cs
Reason: likely edit target; small file; symbol retrieval: symbols CloudWarsData/CreateMatch/DeleteMatch match cloud,wars,data,match,unit,add; file name matches cloud,wars,data
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Entities.Game;
using CloudWars.Entities.Player;
using Microsoft.SqlServer.Types;

namespace CloudWars.DataAccess.Sql
{
    /// <summary>
    /// Expose functionality 
    /// </summary>
    public class CloudWarsData
    {
        

        /// <summary>
        /// Instantiate a match in the DB
        /// </summary>
        /// <param name="player1">Player1 is rebels</param>
        /// <param name="player2">Player2 is empire</param>
        public static Guid CreateMatch(Guid player1, Guid player2)
        {
            Match m = new Match { Id = Guid.NewGuid(), Player1 = player1, Player2 = player2, Turn = player1 };
            CloudWarsDB.Matches.Insert(m);
            //create the match units
            MatchUnit mu;
            var rebels = CloudWarsDB.VanillaUnits.Where(v=> v.IsRebel);
            var empire = CloudWarsDB.VanillaUnits.Where(v=> !v.IsRebel);
            foreach (var v in rebels)
            {
                mu = new MatchUnit { MatchId = m.Id, PlayerId = player1, UnitId = v.Id, MaxHealth = v.MaxHealth, Health = v.MaxHealth, Name = v.Name, Id = Guid.NewGuid(), Col = 0, Row = 0 };
                CloudWarsDB.MatchUnits.Insert(mu);
            }
            foreach (var v in empire)
            {
                mu = new MatchUnit { MatchId = m.Id, PlayerId = player2, UnitId = v.Id, MaxHealth = v.MaxHealth, Health = v.MaxHealth, Name = v.Name, Id = Guid.NewGuid(), Col = 0, Row = 0 };
                CloudWarsDB.MatchUnits.Insert(mu);
            }

            return m.Id;
        }


        public static void DeleteMatch(Guid matchId)
        {
            CloudWarsDB.MatchUnits.Delete(new { MatchId = matchId });
            CloudWarsDB.Matches.Delete(new { Id = matchId });
        }

        public static Match GetMatch(Guid matchId)
        {
            return CloudWarsDB.Matches.GetSingle(new { Id = matchId });
        }


        public static IEnumerable<MatchUnit> GetUnits(Guid matchId)
        {
            return CloudWarsDB.MatchUnits.GetMany(new { MatchId = matchId });
        }


        public static void UpdateMatch(object values, object where)
        {
            CloudWarsDB.Matches.UpdateWithWhere( values: values, where: where);
        }


        public static void UpdateMatchUnit(object values, object where)
        {
            CloudWarsDB.MatchUnits.UpdateWithWhere(values: values, where: where);
        }

        public static void AddNotification(PlayerNotification notification)
        {
            CloudWarsDB.PlayerNotifications.Insert(notification);
        }


        public static IEnumerable<Match> GetMatches()
        {
            return CloudWarsDB.Matches.GetAll();
        }

        public static IEnumerable<Player> GetPlayers()
        {
            return CloudWarsDB.Players.GetAll();
        }

        public static void UpdatePlayer(Player player)
        {
            CloudWarsDB.Players.Update(player);
        }

        public static void UpdatePlayer(object values, object where)
        {
            CloudWarsDB.Players.UpdateWithWhere(values: values, where: where);
        }

        public static void PlayerIsOnline(string liveId, string clientId, double latitude, double longitude)
        {
            var location = SqlGeography.Point(latitude,longitude,4326);
            CloudWarsDB.Players.UpdateWithWhere(values: new { IsOnline = true, Status = PlayerStatus.OnLine, ClientId = clientId, Location = location }, where: new { LiveId = liveId });
        }

        public static void PlayerWin(Guid playerId)
        {
            CloudWarsDB.Players.ExecuteNonQuery(string.Format ("Update Player set Wins = Wins + 1 Where id='{0}'",playerId), new Dictionary<string, object>());
        }

        public static void PlayerLose(Guid playerId)
        {
            CloudWarsDB.Players.ExecuteNonQuery(string.Format("Update Player set Losses = Losses + 1 Where id='{0}'", playerId), new Dictionary<string, object>());
        }


        public static int ActiveMatches()
        {
            return CloudWarsDB.Matches.ExecuteScalar<int>("Select Count(id) from Match where Initialized=true ", new Dictionary<string, object>());
        }


        public static Challenge GetChallenge(Guid challengeId)
        {
            return CloudWarsDB.Challenges.GetSingle( where: new { Id = challengeId } );
        }

        public static Guid GetPlayerId(string clientId)
        {
            return CloudWarsDB.Players.ExecuteScalar<Guid>(string.Format("Select Id From Player Where ClientId='{0}'", clientId), new Dictionary<string, object>()); ;
        }

        public static string GetPlayerName(string clientId)
        {
            return CloudWarsDB.Players.ExecuteScalar<string>(string.Format("Select DisplayName From Player Where ClientId='{0}'", clientId), new Dictionary<string, object>()); ;
        }


        public static string GetClientId(Guid playerId)
        {
            return CloudWarsDB.Players.ExecuteScalar<string>(string.Format("Select ClientId From Player Where Id='{0}'",playerId),new Dictionary<string,object> ());
        }

        public static Guid? IsPlayingMatch(Guid playerId)
        {
            var id = CloudWarsDB.Matches.ExecuteScalar<Guid>(string.Format("Select Id From Match Where (Player1 ='{0}' OR Player2 ='{0}') AND PlayingNow=1", playerId), new Dictionary<string, object>());
            if(id == Guid.Empty )
                return null;
            return id;
        }

        public static Guid ChallengePlayer(Guid fromId, Guid toId)
        {
            var c = new Challenge { Id = Guid.NewGuid(), Player1 = fromId, Player2 = toId };
            CloudWarsDB.Challenges.Insert(c);
            return c.Id;
        }

        public static void AcceptChallenge(Guid challengeId)
        {
            //accepting the challenge means to delete it
            DeleteChallenge(challengeId);
        }

        public static void RejectChallenge(Guid challengeId)
        {
            DeleteChallenge(challengeId);
        }


        private static void DeleteChallenge(Guid challengeId)
        {
            CloudWarsDB.Challenges.Delete(where: new { Id = challengeId });
        }

        public static int OnlinePlayers()
        {
            return CloudWarsDB.Players.ExecuteScalar<int>("Select Count(id) from Player where IsOnline=true ", new Dictionary<string, object>());
        }


        public static IEnumerable<Player> GetOnlinePlayers()
        {
            return CloudWarsDB.Players.GetMany(new { IsOnline = true }, Needletail.DataAccess.Engines.FilterType.AND, new { Wins = "DESC" },null);
        }

        public static IEnumerable<Player> GetOnlinePlayers(string liveId)
        {
            return CloudWarsDB.Players.GetMany("Select *", string.Format("IsOnline = 1 AND LiveId<>'{0}'", liveId), "Wins DESC");
        }

        public static IEnumerable<Player> GetOnlinePlayersNearBy(string liveId)
        {
            string select = string.Format("DECLARE @Iam_at geography SET @Iam_at = (select Location from player where LiveId='{0}')",liveId);
            string where = string.Format( "@Iam_at.STDistance(Location)<100  and IsOnline = 1 And LiveId <> '{0}'",liveId);
            string orderBy = "Wins";
            return CloudWarsDB.Players.GetMany(string.Format ("{0} Select * ",select), where, orderBy);
        }

        public static IEnumerable<Player> GetTop10Players()
        {
            return CloudWarsDB.Players.GetMany(new { }, Needletail.DataAccess.Engines.FilterType.AND, new { Wins = "DESC" }, 10);
        }

        public static Player GetPlayer(Guid playerId)
        {
            return CloudWarsDB.Players.GetSingle( where: new { Id = playerId });
        }

    }
}
```

File: CloudWars.Entities/Game/Match.cs
Reason: likely edit target; small file; reasons lexical-match, symbol-match, type-declaration; lexical match; symbol/token match for cloud, war, game, public, can; symbol retrieval: symbols Match match match
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;

namespace CloudWars.Entities.Game
{
    public class Match
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public Guid Player1 { get; set; }
        public Guid Player2 { get; set; }
        public Guid Turn { get; set; }
        public bool Player1Ready { get; set; }
        public bool Player2Ready { get; set; }
        public bool Initialized { get; set; }
        public bool MatchEnded { get; set; }
        public Guid Winner { get; set; }
        public bool PlayingNow { get; set; }
    }
}
```

File: CloudWars.Entities/Player/Player.cs
Reason: likely edit target; small file; symbol retrieval: symbols  match ; references edge from seed SpaceBattleClientFeedbackDbTests.cs: uses type Player
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;
using Microsoft.SqlServer.Types;

namespace CloudWars.Entities.Player
{
    public class Player
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public string DisplayName { get; set; }
        public string Avatar { get; set; }
        public int Wins { get; set; }
        public int Losses { get; set; }
        public string Status { get; set; }
        public bool IsOnline { get; set; }
        public DateTime LastActivity { get; set; }
        public SqlGeography Location { get;set; }
        public string ClientId { get; set; }
        public string LiveId { get; set; }
    }
}
```

EXPANDED EDIT TARGET CONTEXT

(none)

SUPPORTING CONTEXT

File: CloudWars.Entities/Game/MatchUnit.cs
Reason: symbol retrieval: symbols MatchUnit match match,unit; file name matches match,unit
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;

namespace CloudWars.Entities.Game
{
    public class MatchUnit
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public Guid PlayerId { get; set; }
        public Guid MatchId { get; set; }
        public Guid UnitId { get; set; }
        public string Name { get; set; }
        public int MaxHealth { get; set; }
        public int Health { get; set; }
        public int Row { get; set; }
        public int Col { get; set; }
    }
}
```

File: CloudWars.Entities/Player/PlayerStatus.cs
Reason: symbol retrieval: symbols  match ; references edge from seed SpaceBattleClientFeedbackDbTests.cs: uses type PlayerStatus
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CloudWars.Entities.Player
{
    public class PlayerStatus
    {
        public const string OnLine = "On Line";
        public const string OffLine = "Off Line";
        public const string Playing = "Playing";
    }
}
```

File: CloudWars.Entities/Game/PlayerNotification.cs
Reason: symbol retrieval: symbols  match ; references edge from seed SpaceBattleClientFeedbackDbTests.cs: uses type PlayerNotification
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;

namespace CloudWars.Entities.Game
{
    public class PlayerNotification
    {
        [TableKeyAttribute(CanInsertKey = true)]
        public Guid Id { get; set; }
        public Guid PlayerId { get; set; }
        public Guid MatchId { get; set; }
        public string NotificationType { get; set; }
        public Guid? OtherPlayer { get; set; }
        public int? Row { get; set; }
        public int? Col { get; set; }
    }
}
```

File: CloudWars.Game/Models/AccountModels.cs
Reason: reasons lexical-match, symbol-match, type-declaration; lexical match; symbol/token match for cloud, war, game, public, default
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Globalization;
using System.Web.Security;

namespace CloudWars.Game.Models
{
    public class UsersContext : DbContext
    {
        public UsersContext()
            : base("DefaultConnection")
        {
        }

        public DbSet<UserProfile> UserProfiles { get; set; }
    }

    [Table("UserProfile")]
    public class UserProfile
    {
        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int UserId { get; set; }
        public string UserName { get; set; }
    }

    public class RegisterExternalLoginModel
    {
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }

        public string ExternalLoginData { get; set; }
    }

    public class LocalPasswordModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class LoginModel
    {
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class RegisterModel
    {
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class ExternalLogin
    {
        public string Provider { get; set; }
        public string ProviderDisplayName { get; set; }
        public string ProviderUserId { get; set; }
    }
}
```

File: CloudWars.Common/Other/Enums.cs
Reason: reasons lexical-match, related-source, relationship, symbol-match, type-declaration; lexical match; symbol/token match for cloud, war, public, not, game; related source file for selected context
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CloudWars.Common.Other
{
    public enum Command 
    { 
        NotYourTurn,
        ChallengePlayer,
        ChallengeAccepted,
        StartGame,
        EndGame,
        PlayerOnline,
        PlayerOffLine,
        GameAction
    }


    public enum GameAction
    { 
        PlayerReady,
        UnitMoved,
        Attack,
        ShotMade,
        ShotMissed
    }
        
}
```

File: CloudWars.Common/IGame.cs
Reason: reasons lexical-match, related-source, relationship, symbol-match; lexical match; symbol/token match for game, cloud, war, unit, public; related source file for selected context
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common.Units;
using CloudWars.Common.Other;

namespace CloudWars.Common
{
    public interface IGame
    {
        void ChallengePlayer(Guid fromId, Guid toId);
        
        /// <summary>
        /// Accept the challenge 
        /// </summary>
        /// <returns>MatchId, player 1 id, player 2 id</returns>
        Tuple<Guid,Guid,Guid> AcceptChallenge(Guid challengeId);
        Tuple<string, string> RejectChallenge(Guid challengeId);
        void CreateMatch(Guid player1, Guid player2);
        void Initialize(object initialState);
        void PlayerMoveTo(Position coordinates, Guid unitId);
        Message PlayerAttack(Position coordinates, Guid playerId);
        void PlayerReady(Guid playerId);
        Message MatchFinished(Guid winner, Guid losser);
        Guid MatchId { get; set; }
        Guid Player1 { get; set; }
        Guid Player2 { get; set; }
        Guid Turn { get; set; }
        bool Player1Ready { get; set; }
        bool Player2Ready { get; set; }
        void PauseMatch();
        void RestartMatch();
        List<IGameUnit> Units { get; }
    }

}
```

File: CloudWars.Common/IClientFeedback.cs
Reason: reasons lexical-match, module-anchor, related-source, relationship, symbol-match; lexical match; symbol/token match for cloud, war, public, unit; related source file for selected context; module match
Snippet:
```csharp
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common.Other;

namespace CloudWars.Common
{
    public interface IClientFeedback
    {
        void PlayerWon(Guid playerId, Guid matchId);
        void PlayerLost(Guid playerId, Guid matchId);
        void ChallengePlayer(Guid fromPlayer, Guid toPlayer);
        void ChallengeAccepted(Guid matchId,Guid player1, Guid player2);
        void StartMatch(Guid matchId, Guid player1, Guid player2);
        void ShotMade(Guid matchId, Guid player1, Guid player2, int healthAfterAttack, Guid unitId, Position coordinates);
        void ShotMissed(Guid matchId, Guid player1, Guid player2, Position coordinates);


    }
}
```