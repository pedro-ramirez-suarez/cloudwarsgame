# system

You are CodeLead, a senior software engineer preparing a coding task for an AI coding agent.

Your job is not to write code.

Your job is to:
1. Understand the user request.
2. Use the repository context to identify what is clear.
3. Identify missing requirements.
4. Identify risky assumptions.
5. Detect contradictions with the existing codebase.
6. Ask useful follow-up questions.
7. Produce an implementation-ready prompt for a coding agent.

Important rules:
- Do not invent features that are not requested or visible in the codebase.
- Do not assume business behavior if multiple valid options exist.
- If the request is vague, ask questions.
- If the codebase already shows a clear pattern, mention it.
- Keep the final prompt practical and specific.
- The final prompt should instruct the coding agent to inspect relevant files first.
- The final prompt should include constraints: keep changes minimal, reuse existing patterns, do not add dependencies unless necessary, do not refactor unrelated code, summarize planned changes before editing, and add or update tests only when appropriate.
- Return only valid JSON matching the requested schema.
- Use the exact camelCase keys from the schema.
- Do not use snake_case keys such as missing_requirements, risky_assumptions, follow_up_questions, or implementation_ready_prompt.
- Do not wrap the JSON in Markdown code fences.

Strategy behavior:
fast:
- Use minimal preflight.
- Do not ask unnecessary questions.
- Produce a concise implementation-ready prompt.
- Use when the task is obvious, low-risk, and localized.

clarify:
- Identify ambiguity and assumptions.
- Ask targeted follow-up questions.
- Produce a prompt that either uses safe defaults or clearly tells the coding agent to confirm before implementing.

architect:
- Include everything from clarify.
- Add implementation planning.
- Identify files/areas to inspect first.
- Include sequencing and test guidance.
- Use for multi-file features, new commands, new pages, new endpoints, integrations, or refactors.

deep:
- Include everything from architect.
- Add risk analysis, validation plan, explicit non-goals, and recommended phasing if needed.
- Use for auth, permissions, security, data deletion, migrations, schema changes, payments, privacy, or broad cross-cutting changes.

Do not treat strategies as mutually exclusive.
deep includes architect.
architect includes clarify.
clarify includes preflight.
fast includes minimal preflight.

# user

Original user request:
Add one more in-memory characterization fact to the CloudWars.Characterization project, for a behaviour of SpaceBattleGame that the existing facts do not cover; test files only; the root gate must stay green

Selected strategy:
architect

Strategy classification:
{
  "strategy": "architect",
  "confidence": 0.78,
  "reasons": [
    "Likely needs planning across code areas: test."
  ]
}

Strategy settings:
- askQuestions: true
- maxQuestions: 5
- includeImplementationPlan: true
- includeRiskAnalysis: false
- includeValidationPlan: true
- includeNonGoals: true
- temperature: 0.2
- maxTokens: 12000

Repository root:
C:\src\cloudwarsgame

Package info:
(no package.json found)

Project profile:
Project type: existing
Greenfield: false
Detected languages:
- C# (0.95): Found 68 .cs files; Found CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj; Found CloudWars.Characterization/CloudWars.Characterization.csproj; Found CloudWars.Common/CloudWars.Common.csproj; Found CloudWars.sln
- JavaScript (0.72): Found 40 .js files
Detected tools/frameworks:
- .NET (runtime, 0.95): Found CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj; Found CloudWars.Characterization/CloudWars.Characterization.csproj; Found CloudWars.Common/CloudWars.Common.csproj; Found CloudWars.DataAccess/CloudWars.DataAccess.csproj
- .NET test (test, 0.85): Found common .NET test package in .csproj
Important project files:
- CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj: C# project file.
- CloudWars.Characterization/CloudWars.Characterization.csproj: C# project file.
- CloudWars.Common/CloudWars.Common.csproj: C# project file.
- CloudWars.DataAccess/CloudWars.DataAccess.csproj: C# project file.
- CloudWars.Engine/CloudWars.Engine.csproj: C# project file.
- CloudWars.Entities/CloudWars.Entities.csproj: C# project file.
- CloudWars.Game/CloudWars.Game.csproj: C# project file.
- CloudWars.Glue/CloudWars.Glue.csproj: C# project file.
- CloudWars.SpaceBattle/CloudWars.SpaceBattle.csproj: C# project file.
- CloudWars.sln: C# solution file.
- docs/codelead/dossier/README.md: Project documentation.
Suggested validation commands:
- dotnet build
- dotnet test
Summary: Detected an existing project using C#, JavaScript; tools include .NET, .NET test.
Notes:
- This appears to be an existing project.
- Follow existing project structure, languages, tools, dependencies, and patterns.
- Do not introduce new dependencies unless clearly needed.
- Use suggested validation commands when appropriate: dotnet build, dotnet test.

Project library summary:
Summary: Detected an existing project using C#, JavaScript; tools include .NET, .NET test. ProjectLibrary indexed 180 files, 13 modules, and 500 relationships.
Indexed files: 180
Modules: 13
Relationships: 500
Detected symbols: 472
Top modules:
- CloudWars.Game: 84 files; role source; languages C#, CSS, HTML, JavaScript, Markdown, XML
- docs/codelead: 30 files; role docs; languages JSON, Markdown
- CloudWars.Common: 11 files; role source; languages C#, XML
- CloudWars.Entities: 10 files; role source; languages C#, XML
- CloudWars.DataAccess: 9 files; role source; languages C#, XML
- CloudWars.Characterization.Db: 7 files; role test; languages C#, XML
- CloudWars.SpaceBattle: 7 files; role source; languages C#, XML
- pilot-after: 5 files; role data; languages JSON
Notes:
- ProjectLibrary is deterministic and heuristic-only; use it as orientation, not as proof of relevance.

Context pack summary:
Summary: Selected 12 files: 6 source, 5 test, 0 project/config anchors, 9 relationship-linked.
Candidate files considered: 180
Max files: 12
Notes:
- ContextPack used ProjectLibrary roles, symbols, tokens, modules, and relationships.
Selected files:
- CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs: role test; score 80; reasons lexical-match, related-test, relationship, symbol-match
- CloudWars.SpaceBattle/SpaceBattleGame.cs: role source; score 78; reasons lexical-match, related-source, relationship, symbol-match
- CloudWars.Common/Other/Enums.cs: role source; score 73; reasons lexical-match, related-source, relationship, symbol-match
- CloudWars.Common/Units/IGameUnit.cs: role source; score 71; reasons lexical-match, related-source, relationship, symbol-match
- CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs: role test; score 71; reasons lexical-match, related-test, relationship, symbol-match
- CloudWars.Characterization.Db/SpaceBattleGameMatchFinishedDbTests.cs: role test; score 71; reasons lexical-match, symbol-match
- CloudWars.Characterization/SpaceBattleGameTests.cs: role test; score 68; reasons lexical-match, symbol-match
- CloudWars.Common/IClientFeedback.cs: role source; score 67; reasons lexical-match, module-anchor, related-source, relationship, symbol-match
- CloudWars.Common/IGame.cs: role source; score 67; reasons lexical-match, related-source, relationship, symbol-match
- CloudWars.Characterization/GameUnitTests.cs: role test; score 67; reasons lexical-match, module-anchor, related-test, relationship, symbol-match
- CloudWars.DataAccess/Sql/CloudWarsDB.cs: role source; score 65; reasons lexical-match, related-source, relationship, symbol-match
- docs/codelead/dossier/options.json: role docs; score 63; reasons lexical-match, symbol-match

Project guidance:
This appears to be an existing project.
Follow existing project structure, languages, tools, dependencies, and patterns.
Do not introduce new dependencies unless clearly needed.
Use the suggested validation commands when appropriate.

Scanned file count:
184

File tree summary:
- CloudWars.Characterization.Db/CloudWars.Characterization.Db.csproj
- CloudWars.Characterization.Db/Net8Bootstrap.cs
- CloudWars.Characterization.Db/SpaceBattleClientFeedbackDbTests.cs
- CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs
- CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs
- CloudWars.Characterization.Db/SpaceBattleGameMatchFinishedDbTests.cs
- CloudWars.Characterization.Db/SpaceBattlePlayerPresenceDbTests.cs
- CloudWars.Characterization/CloudWars.Characterization.csproj
- CloudWars.Characterization/GameUnitTests.cs
- CloudWars.Characterization/SpaceBattleGameTests.cs
- CloudWars.Common/CloudWars.Common.csproj
- CloudWars.Common/IClientFeedback.cs
- CloudWars.Common/IFactory.cs
- CloudWars.Common/IGame.cs
- CloudWars.Common/IPlayerPresence.cs
- CloudWars.Common/Other/...
- CloudWars.Common/Properties/...
- CloudWars.Common/Units/...
- CloudWars.DataAccess/CloudWars.DataAccess.csproj
- CloudWars.DataAccess/Properties/...
- CloudWars.DataAccess/Queue/...
- CloudWars.DataAccess/Sql/...
- CloudWars.Engine/CloudWars.Engine.csproj
- CloudWars.Engine/Properties/...
- CloudWars.Engine/WorkerRole.cs
- CloudWars.Entities/CloudWars.Entities.csproj
- CloudWars.Entities/Game/...
- CloudWars.Entities/Player/...
- CloudWars.Entities/Properties/...
- CloudWars.Game/App_Start/...
- CloudWars.Game/CloudWars.Game.csproj
- CloudWars.Game/Code/...
- CloudWars.Game/Content/...
- CloudWars.Game/Controllers/...
- CloudWars.Game/Filters/...
- CloudWars.Game/Global.asax.cs
- CloudWars.Game/Migrations/...
- CloudWars.Game/Models/...
- CloudWars.Game/Properties/...
- CloudWars.Game/Readme.md
- CloudWars.Game/Scripts/...
- CloudWars.Game/ServerClientEntities/...
- CloudWars.Game/Views/...
- CloudWars.Glue/Class1.cs
- CloudWars.Glue/CloudWars.Glue.csproj
- CloudWars.Glue/Properties/...
- CloudWars.SpaceBattle/CloudWars.SpaceBattle.csproj
- CloudWars.SpaceBattle/Properties/...
- CloudWars.SpaceBattle/SpaceBattleClientFeedback.cs
- CloudWars.SpaceBattle/SpaceBattleFactory.cs
- CloudWars.SpaceBattle/SpaceBattleGame.cs
- CloudWars.SpaceBattle/SpaceBattlePlayerPresence.cs
- CloudWars.SpaceBattle/Units/...
- CloudWars.sln
- Directory.Build.props
- Readme.md
- docs/codelead/...
- license.md
- pilot-after/README.txt
- pilot-after/build-summary.json
- pilot-after/environment.json
- pilot-after/idiom-counts-by-project.json
- pilot-after/idiom-counts.json
- pilot-after/projects.json
- pilot-before/README.txt
- pilot-before/build-summary.json
- pilot-before/environment.json
- pilot-before/idiom-counts.json
- pilot-before/projects.json

Relevant files and snippets:
1. CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs
Role: test (C#)
Score: 80
Reason types: lexical-match, related-test, relationship, symbol-match
Reason: lexical match; symbol/token match for space, battle, game, test, cloud; related test file for selected context
Relationship notes:
- test-target with CloudWars.SpaceBattle/SpaceBattleGame.cs: Test filename and tokens match source file
- same-name with CloudWars.SpaceBattle/SpaceBattleGame.cs: Test and source filenames share meaningful tokens
Snippet:
```
1: using System;
2: using System.Collections.Generic;
3: using System.Linq;
4: using CloudWars.Common;
5: using CloudWars.Common.Other;
6: using CloudWars.Common.Units;
7: using CloudWars.DataAccess.Sql;
8: using CloudWars.Entities.Game;
9: using CloudWars.SpaceBattle;
10: using Xunit;
11: 
12: namespace CloudWars.Characterization.Db
13: {
14:     /// <summary>
15:     /// Database-backed characterization tests for SpaceBattleGame.
16:     /// These tests assert what the code does TODAY against the real database.
17:     /// Private properties (Initialized, PlayingNow) are asserted indirectly
18:     /// through observable behaviour or by reading the persisted Match row.
19:     /// </summary>
20:     public class SpaceBattleGameDbTests : IDisposable
21:     {
22:         private Guid _matchId;
23: 
24:         public void Dispose()
25:         {
26:             if (_matchId != Guid.Empty)
27:             {
28:                 try { CloudWarsData.DeleteMatch(_matchId); }
29:                 catch { /* match may already be deleted by MatchFinished */ }
30:             }
31:         }
32: 
33:         // ─────────────────────────────────────────────────────────────────────
34:...
```

2. CloudWars.SpaceBattle/SpaceBattleGame.cs
Role: source (C#)
Score: 78
Reason types: lexical-match, related-source, relationship, symbol-match
Reason: lexical match; symbol/token match for space, battle, game, cloud, war; related source file for selected context
Relationship notes:
- test-target with CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs: Test filename and tokens match source file
- test-target with CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs: Test filename and tokens match source file
Snippet:
```
1: ﻿using System;
2: using System.Collections.Generic;
3: using System.Linq;
4: using System.Text;
5: using CloudWars.Common;
6: using CloudWars.Common.Other;
7: using CloudWars.Common.Units;
8: using CloudWars.SpaceBattle.Units;
9: using CloudWars.DataAccess.Sql;
10: using CloudWars.Entities.Game;
11: 
12: namespace CloudWars.SpaceBattle
13: {
14: 	public class SpaceBattleGame: IGame
15: 	{
16:         public List<IGameUnit> Units { get; private set; }
17:         public Guid MatchId { get; set; }
18:         public Guid Player1 { get; set; }
19:         public Guid Player2 { get; set; }
20:         public Guid Turn { get; set; }
21:         public bool Player1Ready { get; set; }
22:         public bool Player2Ready { get; set; }
23:         bool Initialized { get; set; }
24:         bool MatchEnded { get; set; }
25:         bool PlayingNow { get; set; }
26:         Guid Winner { get; set; }
27:         private readonly ICloudWarsData _data;
28:         
29: 
30:         public SpaceBattleGame(ICloudWarsData data)
31:         {
32:             _data = data;
33:         }
34: 
35:         public SpaceBattleGame(Guid matchId, bool loadMatchData) : this(new SqlCloudWarsData())
36:...
```

3. CloudWars.Common/Other/Enums.cs
Role: source (C#)
Score: 73
Reason types: lexical-match, related-source, relationship, symbol-match
Reason: lexical match; symbol/token match for cloud, war, not, game; related source file for selected context
Relationship notes:
- imports with CloudWars.Characterization.Db/SpaceBattleClientFeedbackDbTests.cs: Import/using "CloudWars.Common.Other" matches symbol other
- imports with CloudWars.Characterization.Db/SpaceBattleGameDbTests.cs: Import/using "CloudWars.Common.Other" matches symbol other
Snippet:
```
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CloudWars.Common.Other
{
    public enum Command 
    { 
        NotYourTurn,
        ChallengePlayer,
        ChallengeAccepted,
        StartGame,
        EndGame,
        PlayerOnline,
        PlayerOffLine,
        GameAction
    }


    public enum GameAction
    { 
        PlayerReady,
        UnitMoved,
        Attack,
        ShotMade,
        ShotMissed
    }
        
}

```

4. CloudWars.Common/Units/IGameUnit.cs
Role: source (C#)
Score: 71
Reason types: lexical-match, related-source, relationship, symbol-match
Reason: lexical match; symbol/token match for game, cloud, war; related source file for selected context
Relationship notes:
- test-target with CloudWars.Characterization/GameUnitTests.cs: Test filename and tokens match source file
- same-name with CloudWars.Characterization/GameUnitTests.cs: Test and source filenames share meaningful tokens
Snippet:
```
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CloudWars.Common.Units
{
    public interface IGameUnit
    {
        Guid UnitId { get; set; }
        Guid PlayerId { get; set; }
        Guid MatchId { get; set; }
        string Name { get; set; }
        int MaxHealth { get; set; }
        int Health { get; set; }
        int Column { get; set; }
        int Row { get; set; }
        void TakeDamage(int damage);
        void MoveTo(int row, int column);
    }
}

```

5. CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs
Role: test (C#)
Score: 71
Reason types: lexical-match, related-test, relationship, symbol-match
Reason: lexical match; symbol/token match for space, battle, game, test, cloud; related test file for selected context
Relationship notes:
- test-target with CloudWars.SpaceBattle/SpaceBattleGame.cs: Test filename and tokens match source file
- same-name with CloudWars.SpaceBattle/SpaceBattleGame.cs: Test and source filenames share meaningful tokens
Snippet:
```
1: using System;
2: using System.Linq;
3: using CloudWars.DataAccess.Sql;
4: using CloudWars.Entities.Game;
5: using CloudWars.Entities.Player;
6: using CloudWars.SpaceBattle;
7: using Xunit;
8: 
9: namespace CloudWars.Characterization.Db
10: {
11:     /// <summary>
12:     /// Database-backed characterization tests for ChallengePlayer, AcceptChallenge, and RejectChallenge.
13:     /// Asserts what the code does TODAY against the real CloudWars database.
14:     /// </summary>
15:     public class SpaceBattleGameChallengeDbTests : IDisposable
16:     {
17:         private Guid _player1Id;
18:         private Guid _player2Id;
19:         private Guid _challengeId;
20:         private Guid _matchId;
21: 
22:         public void Dispose()
23:         {
24:             if (_matchId != Guid.Empty)
25:             {
26:                 try { CloudWarsData.DeleteMatch(_matchId); }
27:                 catch { }
28:             }
29:             if (_challengeId != Guid.Empty)
30:             {
31:                 try { CloudWarsDB.Challenges.Delete(new { Id = _challengeId }); }
32:                 catch { }
33:             }
34:             if (_player1Id != Guid.Empty)
35:...
```

6. CloudWars.Characterization.Db/SpaceBattleGameMatchFinishedDbTests.cs
Role: test (C#)
Score: 71
Reason types: lexical-match, symbol-match
Reason: lexical match; symbol/token match for space, battle, game, test, cloud
Relationship notes:
- none
Snippet:
```
1: using System;
2: using System.Linq;
3: using CloudWars.Common.Other;
4: using CloudWars.DataAccess.Sql;
5: using CloudWars.Entities.Player;
6: using CloudWars.SpaceBattle;
7: using Xunit;
8: 
9: namespace CloudWars.Characterization.Db
10: {
11:     /// <summary>
12:     /// Database-backed characterization tests for SpaceBattleGame.MatchFinished.
13:     /// Asserts what the code does TODAY against the real CloudWars database.
14:     /// </summary>
15:     public class SpaceBattleGameMatchFinishedDbTests : IDisposable
16:     {
17:         private Guid _player1Id;
18:         private Guid _player2Id;
19:         private Guid _matchId;
20: 
21:         public void Dispose()
22:         {
23:             if (_matchId != Guid.Empty)
24:             {
25:                 try { CloudWarsData.DeleteMatch(_matchId); }
26:                 catch { /* match may already be deleted by MatchFinished */ }
27:             }
28:             if (_player1Id != Guid.Empty)
29:             {
30:                 try { CloudWarsDB.Players.Delete(new { Id = _player1Id }); }
31:                 catch { }
32:             }
33:             if (_player2Id != Guid.Empty)
34:             {
35:...
```

7. CloudWars.Characterization/SpaceBattleGameTests.cs
Role: test (C#)
Score: 68
Reason types: lexical-match, symbol-match
Reason: lexical match; symbol/token match for space, battle, game, test, cloud
Relationship notes:
- none
Snippet:
```
using System;
using CloudWars.Common;
using CloudWars.Common.Other;
using CloudWars.SpaceBattle;
using Xunit;

namespace CloudWars.Characterization
{
    public class SpaceBattleGameTests
    {
        [Fact]
        public void ParameterlessConstructor_Units_IsNull()
        {
            var game = new SpaceBattleGame();

            Assert.Null(game.Units);
        }

        [Fact]
        public void TwoParamConstructor_LoadFalse_SetsMatchId_LeavesTurnAndReadyFlagsAtDefaults()
        {
            var matchId = Guid.NewGuid();
            var game = new SpaceBattleGame(matchId, false);

            Assert.Equal(matchId, game.MatchId);
            Assert.Equal(Guid.Empty, game.Turn);
            Assert.False(game.Player1Ready);
            Assert.False(game.Player2Ready);
        }

        [Fact]
        public void PlayerAttack_PlayerIdNotCurrentTurn_ReturnsNotYourTurn_ShotMissed_WithoutTouchingUnits()
        {
            var game = new SpaceBattleGame();
            var player1 = Guid.NewGuid();
            var player2 = Guid.NewGuid();
            var attacker = Guid.NewGuid(); // deliberately not the current turn

            game.Player1 = player1;
            game....
```

8. CloudWars.Common/IClientFeedback.cs
Role: source (C#)
Score: 67
Reason types: lexical-match, module-anchor, related-source, relationship, symbol-match
Reason: lexical match; symbol/token match for cloud, war; related source file for selected context; module match
Relationship notes:
- imports with CloudWars.Common/Other/Enums.cs: Import/using "CloudWars.Common.Other" matches symbol other
Snippet:
```
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common.Other;

namespace CloudWars.Common
{
    public interface IClientFeedback
    {
        void PlayerWon(Guid playerId, Guid matchId);
        void PlayerLost(Guid playerId, Guid matchId);
        void ChallengePlayer(Guid fromPlayer, Guid toPlayer);
        void ChallengeAccepted(Guid matchId,Guid player1, Guid player2);
        void StartMatch(Guid matchId, Guid player1, Guid player2);
        void ShotMade(Guid matchId, Guid player1, Guid player2, int healthAfterAttack, Guid unitId, Position coordinates);
        void ShotMissed(Guid matchId, Guid player1, Guid player2, Position coordinates);


    }
}


```

9. CloudWars.Common/IGame.cs
Role: source (C#)
Score: 67
Reason types: lexical-match, related-source, relationship, symbol-match
Reason: lexical match; symbol/token match for game, cloud, war; related source file for selected context
Relationship notes:
- imports with CloudWars.Common/Other/Enums.cs: Import/using "CloudWars.Common.Other" matches symbol other
- imports with CloudWars.Common/Units/IGameUnit.cs: Import/using "CloudWars.Common.Units" matches symbol units
Snippet:
```
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CloudWars.Common.Units;
using CloudWars.Common.Other;

namespace CloudWars.Common
{
    public interface IGame
    {
        void ChallengePlayer(Guid fromId, Guid toId);
        
        /// <summary>
        /// Accept the challenge 
        /// </summary>
        /// <returns>MatchId, player 1 id, player 2 id</returns>
        Tuple<Guid,Guid,Guid> AcceptChallenge(Guid challengeId);
        Tuple<string, string> RejectChallenge(Guid challengeId);
        void CreateMatch(Guid player1, Guid player2);
        void Initialize(object initialState);
        void PlayerMoveTo(Position coordinates, Guid unitId);
        Message PlayerAttack(Position coordinates, Guid playerId);
        void PlayerReady(Guid playerId);
        Message MatchFinished(Guid winner, Guid losser);
        Guid MatchId { get; set; }
        Guid Player1 { get; set; }
        Guid Player2 { get; set; }
        Guid Turn { get; set; }
        bool Player1Ready { get; set; }
        bool Player2Ready { get; set; }
        void PauseMatch();
        void RestartMatch();
        List<IGameUnit> Units { get; }
    }

}

```

10. CloudWars.Characterization/GameUnitTests.cs
Role: test (C#)
Score: 67
Reason types: lexical-match, module-anchor, related-test, relationship, symbol-match
Reason: lexical match; symbol/token match for game, test, cloud, war, characterization; related test file for selected context; module match
Relationship notes:
- test-target with CloudWars.Common/Units/IGameUnit.cs: Test filename and tokens match source file
- same-name with CloudWars.Common/Units/IGameUnit.cs: Test and source filenames share meaningful tokens
Snippet:
```
using System;
using CloudWars.Entities.Game;
using CloudWars.SpaceBattle.Units;
using Xunit;

namespace CloudWars.Characterization
{
    public class GameUnitTests
    {
        private static MatchUnit CreateMatchUnit()
        {
            return new MatchUnit
            {
                Id = Guid.NewGuid(),
                UnitId = Guid.NewGuid(),
                PlayerId = Guid.NewGuid(),
                MatchId = Guid.NewGuid(),
                Name = "TestUnit",
                MaxHealth = 10,
                Health = 7,
                Row = 3,
                Col = 5
            };
        }

        [Fact]
        public void Constructor_CopiesPublicFieldsFromMatchUnit_ColMapsToColumn()
        {
            var mu = CreateMatchUnit();
            var unit = new GameUnit(mu);

            Assert.Equal(mu.UnitId, unit.UnitId);
            Assert.Equal(mu.PlayerId, unit.PlayerId);
            Assert.Equal(mu.MatchId, unit.MatchId);
            Assert.Equal(mu.Name, unit.Name);
            Assert.Equal(mu.MaxHealth, unit.MaxHealth);
            Assert.Equal(mu.Health, unit.Health);
            Assert.Equal(mu.Row, unit.Row);
            Assert.Equal(mu.Col, unit.Column)...
```

11. CloudWars.DataAccess/Sql/CloudWarsDB.cs
Role: source (C#)
Score: 65
Reason types: lexical-match, related-source, relationship, symbol-match
Reason: lexical match; symbol/token match for cloud, war, game; related source file for selected context
Relationship notes:
- imports with CloudWars.Characterization.Db/SpaceBattleGameChallengeDbTests.cs: Import/using "CloudWars.DataAccess.Sql" matches symbol sql
- imports with CloudWars.Characterization.Db/SpaceBattlePlayerPresenceDbTests.cs: Import/using "CloudWars.DataAccess.Sql" matches symbol sql
Snippet:
```
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Needletail.DataAccess.Attributes;
using CloudWars.Entities.Game;
using CloudWars.Entities.Player;
using Needletail.DataAccess;

namespace CloudWars.DataAccess.Sql
{
    public class CloudWarsDB
    {
        /// <summary>
        /// The connection string for the game
        /// </summary>
        public const string ConnectionString = "DefaultConnection";

        static DBTableDataSourceBase<Match, Guid> _Matches = new DBTableDataSourceBase<Match, Guid> (ConnectionString, "Match");
        public static DBTableDataSourceBase<Match, Guid> Matches
        {
            get 
            {
                return _Matches;
            }
        }


        static DBTableDataSourceBase<MatchUnit, Guid> _MatchUnits = new DBTableDataSourceBase<MatchUnit, Guid>(ConnectionString, "MatchUnit");
        public static DBTableDataSourceBase<MatchUnit, Guid> MatchUnits
        {
            get
            {
                return _MatchUnits;
            }
        }


        static DBTableDataSourceBase<PlayerUnit, Guid> _PlayerUnits = new DBTableDataSourceBase<PlayerUnit, Guid>(ConnectionString,...
```

12. docs/codelead/dossier/options.json
Role: docs (JSON)
Score: 63
Reason types: lexical-match, symbol-match
Reason: lexical match; symbol/token match for cloud, war, project, behaviour, characterization
Relationship notes:
- none
Snippet:
```
1: {
2:   "schema": "codelead.modernization-options/1",
3:   "generatedAt": "2026-09-21T20:44:07.539Z",
4:   "basis": {
5:     "calibration": "CloudWars pilot, 2026-09-17: 8 landed increments (4 pin, 4 transform) in 24 sessions, 59 model calls, 10.9 h elapsed; rates fitted on 1,467 recorded calls (R² 0.95)",
6:     "callsPerIncrement": 7.375,
7:     "promptTokensPerIncrement": 102325.25,
8:     "completionTokensPerIncrement": 50830.125,
9:     "generationTokPerS": 16,
10:     "prefillTokPerS": 433,
11:     "overheadSPerCall": 3.9,
12:     "elapsedMinutesPerIncrement": 81.75,
13:     "humanRatio": 0.5
14:   },
15:   "options": [
16:     {
17:       "type": {
18:         "id": "T1",
19:         "name": "Platform upgrade in place",
20:         "changes": "Framework, runtime and language version; project format; package versions",
21:         "preserves": "Architecture, code, behaviour, data",
22:         "driver": "Support end, security, hiring",
23:         "pins": "Characterization pins on touched modules; dual-run parity on old and new runtime",
24:         "gates": "Build on both targets; every pin green on both",
25:         "consequences": "IDE and SDK floor rises; CI images...
```

Return JSON with exactly this shape:
{
  "strategy": "architect",
  "confidence": 0.0,
  "strategyReasoning": ["string"],
  "summary": "string",
  "clearRequirements": ["string"],
  "likelyRelevantFiles": [{ "path": "string", "reason": "string" }],
  "ambiguities": [{ "description": "string", "impact": "low | medium | high" }],
  "assumptions": [{ "description": "string", "risk": "low | medium | high", "shouldConfirmWithUser": true }],
  "followUpQuestions": [{ "question": "string", "whyItMatters": "string", "defaultIfUnanswered": "string" }],
  "implementationPlan": ["string"],
  "riskAnalysis": [{ "risk": "string", "impact": "low | medium | high", "mitigation": "string" }],
  "validationPlan": ["string"],
  "nonGoals": ["string"],
  "suggestedValidation": ["string"],
  "finalCodingAgentPrompt": "string"
}

Allowed strategy values: fast, clarify, architect, deep.
Allowed impact/risk values: low, medium, high.
Every required key shown above is required. Optional arrays may be omitted when strategy settings do not request them.
If askQuestions is false, keep followUpQuestions empty unless there is a serious blocker.
If includeImplementationPlan is false, omit implementationPlan or return an empty array.
If includeRiskAnalysis is false, omit riskAnalysis or return an empty array.
If includeValidationPlan is false, omit validationPlan or return an empty array.
If includeNonGoals is false, omit nonGoals or return an empty array.