Prompt not available before model call completed.
